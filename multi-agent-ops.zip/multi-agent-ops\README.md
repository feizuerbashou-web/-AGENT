﻿# 多 Agent 协同运营自动化系统

这是一个零依赖、可直接运行的前端项目，用于演示多 Agent 协同运营自动化工作流。下载 ZIP 后解压，双击 `index.html` 即可使用。

## 功能

- 运营总览：查看活跃 Agent、待办任务、完成任务和自动化规则数量。
- Agent 团队：新增、删除、切换 Agent 状态，并维护角色与技能。
- 任务队列：新增任务、按优先级排序、推进任务状态、删除任务。
- 自动化规则：基于触发条件执行派单、质检任务创建和运营提醒。
- 调度引擎：点击“运行一轮调度”后自动匹配任务与 Agent。
- 运行日志：记录自动化、派单、推进和删除等操作。
- 数据持久化：使用浏览器 `localStorage` 保存状态。
- 数据导入导出：支持 JSON 格式备份和恢复。

## 快速开始

1. 解压 ZIP。
2. 打开 `multi-agent-ops/index.html`。
3. 点击“运行一轮调度”观察系统自动派单与任务推进。

## 文件结构

```text
multi-agent-ops/
  index.html   页面结构
  styles.css   界面样式
  app.js       业务逻辑、调度引擎、数据持久化
  README.md    使用说明
```

## 可继续扩展的方向

- 接入真实大模型 API，让 Agent 生成内容、分析数据或回复工单。
- 增加后端服务和数据库，将本地数据升级为团队共享数据。
- 加入权限、审批流、Webhook、定时任务和消息通知。
- 将调度策略改为可配置权重或规则引擎。

## GitHub Actions 兼容性

项目内置的 `.github/workflows/package.yml` 已使用支持 Node.js 24 的新版 Actions：

- `actions/checkout@v6`
- `actions/upload-artifact@v7`

工作流同时设置了 `FORCE_JAVASCRIPT_ACTIONS_TO_NODE24: true`，可以提前选择 Node.js 24 运行 JavaScript Action，避免 Node.js 20 弃用告警。

## GitHub Pages 部署

项目内置 `.github/workflows/deploy-pages.yml`，用于将静态页面部署到 GitHub Pages。

为避免 `Canceling Pages deployment failed` 这类竞态错误，Pages 部署工作流使用：

```yaml
concurrency:
  group: pages-${{ github.ref }}
  cancel-in-progress: false
```

这会让同一分支的 Pages 部署串行排队，而不是尝试取消已经完成的 deployment。

当前使用的 Actions 版本：

- `actions/checkout@v6`
- `actions/configure-pages@v6`
- `actions/upload-pages-artifact@v5`
- `actions/deploy-pages@v5`

并设置 `FORCE_JAVASCRIPT_ACTIONS_TO_NODE24: true`，提前使用 Node.js 24 运行 JavaScript Actions。
